package com.example.booknotifier

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.format.DateTimeFormatter

class BookCheckWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        const val CHANNEL_ID = "book_notifier_channel"
        const val NOTIF_ID = 9876
        val SEARCH_QUERIES = listOf("Brandon Sanderson", "J.K. Rowling", "Stephen King")
        const val PREFS_NAME = "book_notifier_prefs"
        const val SEEN_KEY_PREFIX = "seen_"
    }

    private val client = OkHttpClient()

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Book notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            nm.createNotificationChannel(channel)
        }
    }

    private fun sendNotification(title: String, body: String) {
        ensureChannel()
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notif = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIF_ID + (title.hashCode() and 0xFFF), notif)
    }

    private fun appendLogLine(line: String) {
        try {
            val file = File(applicationContext.filesDir, "book_log.csv")
            if (!file.exists()) {
                file.writeText("timestamp,query,book_id,title,authors,published_date,info_link\n")
            }
            file.appendText(line + "\n")
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun getSeenIds(prefs: SharedPreferences, query: String): MutableSet<String> {
        return prefs.getStringSet(SEEN_KEY_PREFIX + query, emptySet())?.toMutableSet() ?: mutableSetOf()
    }

    private fun saveSeenIds(prefs: SharedPreferences, query: String, set: Set<String>) {
        prefs.edit().putStringSet(SEEN_KEY_PREFIX + query, set).apply()
    }

    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        for (q in SEARCH_QUERIES) {
            try {
                val encoded = java.net.URLEncoder.encode("inauthor:$q", "utf-8")
                val url = "https://www.googleapis.com/books/v1/volumes?q=$encoded&orderBy=newest&maxResults=10"
                val req = Request.Builder().url(url).header("User-Agent", "BookNotifier/Android").build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string() ?: ""
                if (body.isEmpty()) continue

                val json = JSONObject(body)
                if (!json.has("items")) continue
                val items = json.getJSONArray("items")
                val seen = getSeenIds(prefs, q)

                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val bookId = item.optString("id", "")
                    if (bookId.isEmpty()) continue
                    if (seen.contains(bookId)) continue

                    val vi = item.optJSONObject("volumeInfo") ?: JSONObject()
                    val title = vi.optString("title", "No Title")
                    val authorsArr = vi.optJSONArray("authors")
                    val authors = if (authorsArr != null) {
                        val tmp = mutableListOf<String>()
                        for (k in 0 until authorsArr.length()) tmp.add(authorsArr.optString(k))
                        tmp.joinToString("; ")
                    } else ""
                    val publishedDate = vi.optString("publishedDate", "")
                    val infoLink = vi.optString("infoLink", "")

                    val timestamp = DateTimeFormatter.ISO_INSTANT.format(Instant.now())
                    val csvLine = ""$timestamp","$q","$bookId","${title.replace('\"','\'')}","                 + ""${authors.replace('"','\'')}","$publishedDate","$infoLink""
                    appendLogLine(csvLine)

                    sendNotification("New book for $q", "$title — $authors\nPublished: $publishedDate")
                    seen.add(bookId)
                }
                saveSeenIds(prefs, q, seen)
            } catch (e: Exception) {
                // log or ignore
            }
        }
        return Result.success()
    }
}
