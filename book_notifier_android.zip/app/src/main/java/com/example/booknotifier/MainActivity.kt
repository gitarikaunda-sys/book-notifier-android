package com.example.booknotifier

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    companion object {
        const val WORK_NAME = "book_check_periodic_work"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = Button(this).apply {
            text = "Start background checks (every 15 min)"
            setOnClickListener {
                scheduleWork()
                Toast.makeText(context, "Work scheduled. Checks will run periodically.", Toast.LENGTH_SHORT).show()
            }
        }
        setContentView(b)
    }

    private fun scheduleWork() {
        val workRequest = PeriodicWorkRequestBuilder<BookCheckWorker>(15, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(applicationContext)
            .enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            )
    }
}
